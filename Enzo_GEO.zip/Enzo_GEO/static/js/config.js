// API key
const API_KEY = "pk.eyJ1IjoiY3Jlc2NlbnpvIiwiYSI6ImNqenBscmIzeDByNHgzY281cDk2NGR3aGwifQ.o6To7E1dTDr-T9ycdaddSg";
